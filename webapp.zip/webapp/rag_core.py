# webapp/rag_core.py
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForQuestionAnswering, AutoModelForSeq2SeqLM, pipeline
import torch, re

from . import config

# ---------------- Chroma (no embedding_function on persisted collection) ----------------
_chroma_client = chromadb.PersistentClient(path=config.PERSIST_DIR, settings=Settings(allow_reset=False))
try:
    _collection = _chroma_client.get_collection("heart_faq")
except Exception:
    _collection = _chroma_client.create_collection("heart_faq")

# Our query embedder (must match index build)
_embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# ---------------- Models ----------------
device = 0 if torch.cuda.is_available() else -1

# Extractive QA (continual model)
_tokenizer_ex = AutoTokenizer.from_pretrained(config.MODEL_PATH, use_fast=True)
_model_ex = AutoModelForQuestionAnswering.from_pretrained(config.MODEL_PATH)
_qa_extractive = pipeline(
    "question-answering",
    model=_model_ex,
    tokenizer=_tokenizer_ex,
    device=device,
    handle_impossible_answer=True,
    max_answer_len=64,
    align_to_words=True,
)

# ✅ Lazy generative fallback: created on demand
_qa_generative = None
def _get_generative():
    global _qa_generative
    if _qa_generative is None:
        tok = AutoTokenizer.from_pretrained("google/flan-t5-base")
        mdl = AutoModelForSeq2SeqLM.from_pretrained("google/flan-t5-base")
        _qa_generative = pipeline("text2text-generation", model=mdl, tokenizer=tok, device=device)
    return _qa_generative

# ---------------- Heuristics / cleaning ----------------
NOISE_PATTERNS = [
    r"\bdear\b", r"\bhello\b", r"\bhi\b", r"thank you", r"thanks",
    r"best regards", r"regards", r"yours", r"dr\.", r"\bmd\b",
    r"consult", r"please rate", r"assist you further", r"wish you"
]
NOISE_RE = re.compile("|".join(NOISE_PATTERNS), flags=re.I)

def _is_noisy(text: str) -> bool:
    t = (text or "").lower()
    if NOISE_RE.search(t): return True
    if re.search(r"\bi\b.*doctor", t): return True
    return False

def _clean_context(text: str) -> str:
    t = (text or "")
    t = re.sub(r"(?i)regards.*", "", t)
    t = re.sub(r"(?i)best regards.*", "", t)
    t = re.sub(r"(?i)thank.*", "", t)
    t = re.sub(r"(?i)dr\.\s+[A-Z][a-z].*", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def _keyword_score(text: str, q_words: set) -> int:
    t = (text or "").lower()
    return sum(1 for w in q_words if w in t)

def _source_bonus(meta: dict) -> float:
    src = (meta or {}).get("source", "")
    return 1.0 if isinstance(src, str) and "taskA_ctx.json" in src else 0.0

def _retrieve(question: str, fetch_k: int):
    q_emb = _embedder.encode([question], convert_to_numpy=True).tolist()
    res = _collection.query(
        query_embeddings=q_emb,
        n_results=max(fetch_k, 1),
        include=["documents", "metadatas", "distances"],
    )
    docs  = (res.get("documents") or [[]])[0]
    metas = (res.get("metadatas") or [[]])[0]
    dists = (res.get("distances") or [[]])[0]
    return docs, metas, dists

def _rerank_filter(question: str, docs, metas, dists, top_k: int):
    q_words = {w for w in re.findall(r"[A-Za-z]+", question.lower()) if len(w) > 3}
    scored = []
    for d, m, dist in zip(docs, metas, dists):
        kw = _keyword_score(d, q_words)
        bon = _source_bonus(m)
        noisy = _is_noisy(d)
        score = kw + bon - (1.5 if noisy else 0.0) - float(dist or 0.0)
        scored.append((score, d, m or {}, float(dist or 0.0), noisy))
    scored.sort(key=lambda x: x[0], reverse=True)

    keep_docs, keep_metas, keep_dists, keep_scores = [], [], [], []
    for s, d, m, dist, noisy in scored:
        d_clean = _clean_context(d)
        if len(d_clean) < 60:  # drop ultra-short chunks
            continue
        keep_docs.append(d_clean)
        keep_metas.append(m)
        keep_dists.append(dist)
        keep_scores.append(s)
        if len(keep_docs) >= max(top_k, 1):
            break
    return keep_docs, keep_metas, keep_dists, keep_scores

def answer_question(question: str, top_k: int, fetch_k: int, mode: str):
    # retrieve
    docs, metas, dists = _retrieve(question, fetch_k=fetch_k)
    docs, metas, dists, scores = _rerank_filter(question, docs, metas, dists, top_k=top_k)
    if not docs:
        return {"answer": "Not enough information in the provided context.", "mode_used": "none", "sources": []}

    sources = []
    for d, m, dist, sc in zip(docs, metas, dists, scores):
        sources.append({
            "source": (m.get("source") if isinstance(m, dict) else "unknown") or "unknown",
            "distance": round(float(dist), 4),
            "score": round(float(sc), 2),
        })

    # extractive first
    try:
        ext = _qa_extractive({"context": docs[0], "question": question})
        span = re.sub(r"\s+", " ", (ext.get("answer") or "")).strip()
        conf = float(ext.get("score") or 0.0)
    except Exception as e:
        # Extractive pipeline failed — return graceful JSON
        return {
            "answer": f"Extraction error: {str(e)}",
            "mode_used": "extractive-error",
            "sources": sources
        }

    if mode == "extractive":
        return {
            "answer": (span or "Not enough information in the provided context."),
            "mode_used": "extractive",
            "sources": sources
        }

    if mode == "hybrid":
        if len(span.split()) >= config.MIN_TOKENS and conf >= config.MIN_CONF:
            return {"answer": span, "mode_used": "hybrid(extractive)", "sources": sources}
        # lazy-load small generative only when needed
        try:
            gen_pipe = _get_generative()
            merged = " ".join(docs)[:1400]
            prompt = (
                "You are a concise, factual medical assistant.\n"
                "Answer ONLY from the provided context.\n"
                "- Use short sentences or bullet points.\n"
                "- No greetings/sign-offs/doctor names.\n"
                "- If info not present, reply exactly: 'Not enough information in the provided context.'\n\n"
                f"Question: {question}\nContext:\n{merged}"
            )
            gen = gen_pipe(prompt, max_length=220, do_sample=False)[0]["generated_text"]
            return {"answer": re.sub(r'\s+', ' ', gen).strip(), "mode_used": "hybrid(gen)", "sources": sources}
        except Exception as e:
            # Generative fallback failed — still return extractive span or a clear message
            fallback = span if span else "Not enough information in the provided context."
            return {
                "answer": fallback,
                "mode_used": f"hybrid(extractive-fallback; gen_error={str(e)})",
                "sources": sources
            }

    # pure generative (rarely needed)
    try:
        gen_pipe = _get_generative()
        merged = " ".join(docs)[:1400]
        prompt = (
            "You are a concise, factual medical assistant.\n"
            "Answer ONLY from the provided context.\n"
            "- Use short sentences or bullet points.\n"
            "- No greetings/sign-offs/doctor names.\n"
            "- If info not present, reply exactly: 'Not enough information in the provided context.'\n\n"
            f"Question: {question}\nContext:\n{merged}"
    )
        gen = gen_pipe(prompt, max_length=220, do_sample=False)[0]["generated_text"]
        return {"answer": re.sub(r'\s+', ' ', gen).strip(), "mode_used": "generative", "sources": sources}
    except Exception as e:
        return {
            "answer": f"Generative error: {str(e)}",
            "mode_used": "generative-error",
            "sources": sources
        }