# webapp/api.py
from fastapi import FastAPI, HTTPException
# ... (imports unchanged)
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

#  use package-relative imports
from . import config
from .rag_core import answer_question

app = FastAPI(title="Heart Health Chatbot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AskRequest(BaseModel):
    question: str
    top_k: int = config.TOP_K
    fetch_k: int = config.FETCH_K
    mode: str = config.MODE

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/ask")
def ask(req: AskRequest):
    try:
        if not req.question or not req.question.strip():
            raise HTTPException(status_code=422, detail="Question must be non-empty.")
        result = answer_question(req.question, req.top_k, req.fetch_k, req.mode)
        return {
            "answer": result.get("answer") or "Not enough information in the provided context.",
            "mode_used": result.get("mode_used", req.mode),
            "sources": result.get("sources", []),
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback; traceback.print_exc()
        return {"answer": f"Server error: {str(e)}", "mode_used": "error", "sources": []}