import os

# Directories
PERSIST_DIR = os.getenv("PERSIST_DIR", "./data/chroma")
MODEL_PATH = os.getenv("MODEL_PATH", "./models/taskB_continual")

# RAG settings
TOP_K = int(os.getenv("TOP_K", 4))
FETCH_K = int(os.getenv("FETCH_K", 10))
MODE = os.getenv("MODE", "hybrid")  # extractive | hybrid | generative

# CORS
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")

# Safety filters
MIN_TOKENS = int(os.getenv("MIN_TOKENS", 6))
MIN_CONF = float(os.getenv("MIN_CONF", 0.25))